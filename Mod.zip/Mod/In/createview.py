# Databricks notebook source
import logging
import json

# COMMAND ----------

# MAGIC %run ./common_libs_mn/parameters
# MAGIC

# COMMAND ----------

# MAGIC %run ./common_libs_mn/publish
# MAGIC

# COMMAND ----------

# MAGIC %run ./common_libs_mn/transformer

# COMMAND ----------

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("create_views")  
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

input_parameter_specs = {
  "pipeline_config_params": ("Pipeline Config Params in json string format", "{}", json.loads),
}
input_parameters = create_input_parameters(input_parameter_specs, dbutils=dbutils)
input_parameter_values = get_input_parameter_values(input_parameters, dbutils=dbutils)

logger.info(f"Input parameters: {json.dumps(input_parameter_values, indent=4)}")

# COMMAND ----------

THRESHOLDS_VIEW = input_parameter_values["pipeline_config_params"]["thesholds_view"]
THRESHOLDS_VIEW_SOURCE = input_parameter_values["pipeline_config_params"]["thesholds_view_source"]
INSIGHTS_VIEW = input_parameter_values["pipeline_config_params"]["insights_view"]
INSIGHTS_VIEW_SOURCE = input_parameter_values["pipeline_config_params"]["insights_view_source"]
INSIGHTS_VIEW_SOURCE_LF = input_parameter_values["pipeline_config_params"]["insights_view_source_lf"]
AUDIT_VIEW = input_parameter_values["pipeline_config_params"]["audit_view"]
AUDIT_VIEW_SOURCE = input_parameter_values["pipeline_config_params"]["audit_view_source"]

logger.info(THRESHOLDS_VIEW)
logger.info(THRESHOLDS_VIEW_SOURCE)
logger.info(INSIGHTS_VIEW)
logger.info(INSIGHTS_VIEW_SOURCE)
logger.info(AUDIT_VIEW)
logger.info(AUDIT_VIEW_SOURCE)

# COMMAND ----------

thresholds_view_query = f"""
CREATE OR REPLACE VIEW {THRESHOLDS_VIEW} AS
SELECT *
FROM {THRESHOLDS_VIEW_SOURCE};
"""

spark.sql(thresholds_view_query)

# COMMAND ----------

insights_view_query = f"""
CREATE OR REPLACE VIEW {INSIGHTS_VIEW} AS
SELECT *
FROM {INSIGHTS_VIEW_SOURCE}
UNION ALL 
SELECT * FROM {INSIGHTS_VIEW_SOURCE_LF} ;
"""

spark.sql(insights_view_query)

# COMMAND ----------

audit_view_query = f"""
CREATE OR REPLACE VIEW {AUDIT_VIEW} AS
SELECT 
  job_id,
  task_name,
  start_run_time,
  end_run_time, 
  profiledate,
  number_distinct_ban,
  profile_name,
  status
FROM {AUDIT_VIEW_SOURCE};
"""

spark.sql(audit_view_query)