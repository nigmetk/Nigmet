# Databricks notebook source
# MAGIC %md
# MAGIC #### Import libs and init logger
# MAGIC

# COMMAND ----------

import logging
import json
from datetime import datetime  
from dateutil.parser import isoparse

# COMMAND ----------

# MAGIC %run ./common_libs/parameter_utils_nb

# COMMAND ----------

# MAGIC %run ./common_libs/publish_utils_nb

# COMMAND ----------

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("publish")  
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read input job parameters

# COMMAND ----------

input_parameter_specs = {
  "run_id": ("Run ID", "default_run_id", None),
  "pipeline_name": ("Pipeline Name", "default_pipeline_name", None),
  "start_run_timestamp": ("Pipeline run start timestamp", "-", None),
  "error_msg": ("Error message, blank if none", "", None),
  "pipeline_config_params": ("Pipeline Config Params in json string", "{}", json.loads),
  "input": ("Other inputs in json string format", "{}", json.loads)
}
input_parameters = create_input_parameters(input_parameter_specs, dbutils=dbutils)
input_parameter_values = get_input_parameter_values(input_parameters, dbutils=dbutils)

logger.info(f"Input parameters: {json.dumps(input_parameter_values, indent=4)}")

# COMMAND ----------

"""
{"batch_uuid": "1f629299-a61b-4841-9ce4-0fbf6e83aee3",  
"result_data_table": "devrzrcore.bdidb.tmp_ml_latefee_scores"}
"""

"""
{"inference_scores_table": "devrzrcore.bdidb.dbr_latefee_customer_ml_callintent_insights", 
"inference_audit_table": "devrzrcore.bdidb.dbr_customer_ml_callintent_audit", 
"inference_scores_view": "devrzrcore.bdidb.dbr_latefee_customer_ml_callintent_insights_v"}
"""

# COMMAND ----------

# Read input job parameter
RUN_ID = input_parameter_values["run_id"]
PIPELINE_NAME = input_parameter_values["pipeline_name"]
ERROR_MSG = input_parameter_values["error_msg"]
START_RUN_TIMESTAMP = isoparse(input_parameter_values["start_run_timestamp"])
SCORES_TABLE = input_parameter_values["pipeline_config_params"]["inference_scores_table"]
SCORES_VIEW = input_parameter_values["pipeline_config_params"]["inference_scores_view"]
AUDIT_TABLE = input_parameter_values["pipeline_config_params"]["inference_audit_table"]
PROFILE_DATE = get_profile_date(input_parameter_values["pipeline_config_params"].get("profiledate", None))
STATUS = "SUCCESS" if ERROR_MSG == "" else "FAIL"

# COMMAND ----------

logger.info("RUN_ID: %s", RUN_ID)
logger.info("PIPELINE_NAME: %s", PIPELINE_NAME)
logger.info("ERROR_MSG: %s", ERROR_MSG)
logger.info("START_RUN_TIMESTAMP: %s", START_RUN_TIMESTAMP)
logger.info("SCORES_TABLE: %s", SCORES_TABLE)
logger.info("SCORES_VIEW: %s", SCORES_VIEW)
logger.info("AUDIT_TABLE: %s", AUDIT_TABLE)
logger.info("PROFILE_DATE: %s", PROFILE_DATE)
logger.info("STATUS: %s", STATUS)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Publish to scores and audit table

# COMMAND ----------

audit_df = None
end_run_timestamp = datetime.utcnow()
if STATUS == "SUCCESS":
  # Read prediction results
  INPUT_DATA_TABLE = input_parameter_values["input"]["result_data_table"]
  INPUT_DATA_BATCH_UUID = input_parameter_values["input"]["batch_uuid"]
  inference_result = spark.sql(f"select * from {INPUT_DATA_TABLE} where batch_uuid='{INPUT_DATA_BATCH_UUID}'")
  
  # create insights df
  insight_scores_df = get_insight_scores_df(inference_result=inference_result, run_id=RUN_ID, intent_name="late_fee")
  
  # create success audit df
  count = inference_result.count()
  audit_df = get_audit_df(status="SUCCESS", run_id=RUN_ID, count=count, profiledate=PROFILE_DATE, start_run_timestamp=START_RUN_TIMESTAMP, end_run_timestamp=end_run_timestamp, task_name="late_fee", spark_session=spark)
  
  # write insights to uc
  insight_scores_df.write.format("delta").partitionBy("profiledate").mode("append").saveAsTable(SCORES_TABLE) 
else:
  # create fail audit df
  audit_df = get_audit_df(status="FAIL", run_id=RUN_ID, count=0, start_run_timestamp=START_RUN_TIMESTAMP, end_run_timestamp=end_run_timestamp, profiledate=PROFILE_DATE, task_name="late_fee", spark_session=spark)

# write audit to uc
audit_df.write.format("delta").mode("append").saveAsTable(AUDIT_TABLE) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create scores view

# COMMAND ----------

if STATUS == "SUCCESS":
  scores_view_sql = f"""
      CREATE OR REPLACE VIEW {SCORES_VIEW} AS
      WITH RankedAudit AS (
          SELECT *,
                ROW_NUMBER() OVER (PARTITION BY profiledate ORDER BY end_run_time DESC) AS rn
          FROM {AUDIT_TABLE}
          WHERE status = 'SUCCESS' AND task_name = 'late_fee'
      )
      SELECT s.profiledate as inference_date, 
          s.intent_name, 
          CAST(s.intent_scores AS DECIMAL(4,3)), 
          split_part(s.customerkey, '_', -1) as ban
      FROM {SCORES_TABLE} s
      JOIN (
          SELECT *
          FROM RankedAudit
          WHERE rn = 1
      ) a ON s.run_id = a.run_id;
    """

  logger.info(f"Creating scores view {SCORES_VIEW} for scores table {SCORES_TABLE}")
  print(scores_view_sql)
  spark.sql(scores_view_sql)

# COMMAND ----------

# Raise exception if the pipeline failed, allready audited
if STATUS == "FAIL":
  raise RuntimeError(ERROR_MSG)

# COMMAND ----------

# MAGIC %md
# MAGIC