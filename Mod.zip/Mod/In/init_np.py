# Databricks notebook source
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
import time
import logging
import json
import pytz

# COMMAND ----------

# MAGIC %run ./common_libs/parameter_utils_nb

# COMMAND ----------

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("init")  
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

input_parameter_specs = {
  "run_id": ("Run ID", "default_run_id", str.strip),
  "pipeline_name": ("Pipeline Name", "default_pipeline_name", str.strip),
  "pipeline_config_params": ("Pipeline Config Params", "{}", json.loads)
}

input_parameters = create_input_parameters(input_parameter_specs, dbutils=dbutils)
input_parameter_values = get_input_parameter_values(input_parameters, dbutils=dbutils)

logger.info(f"Input parameters: {json.dumps(input_parameter_values, indent=4)}")

# COMMAND ----------

RUN_ID = input_parameter_values["run_id"]
PIPELINE_NAME = input_parameter_values["pipeline_name"]
TRIGGER_TOTAL_TIME = int(input_parameter_values["pipeline_config_params"]["trigger_total_time"].strip())
TRIGGER_TIMER_INTERVAL = int(input_parameter_values["pipeline_config_params"]["trigger_time_interval"].strip())
TRIGGER_TABLE =  input_parameter_values["pipeline_config_params"]["trigger_table"].strip()
PROFILE_DATE = get_profile_date(input_parameter_values["pipeline_config_params"].get("profiledate", None))

# COMMAND ----------

logger.info("RUN_ID: %s", RUN_ID)
logger.info("PIPELINE_NAME: %s", PIPELINE_NAME)
logger.info("TRIGGER_TOTAL_TIME: %s", TRIGGER_TOTAL_TIME)
logger.info("TRIGGER_TIMER_INTERVAL: %s", TRIGGER_TIMER_INTERVAL)
logger.info("TRIGGER_TABLE: %s", TRIGGER_TABLE)
logger.info("PROFILE_DATE: %s", PROFILE_DATE)

# COMMAND ----------

logger.info(f"Checking table {TRIGGER_TABLE} for data for date {PROFILE_DATE}")

# COMMAND ----------

def get_profiledate_count(table: str, profiledate: str) -> None:
  df = spark.sql(f"""SELECT count(*) as count FROM {table} WHERE PROFILEDATE = '{profiledate}' """)
  count = df.collect()[0]['count']
  return count

def wait_for_updated_customer_profile(table: str, date: str, total_time: int, time_interval: int):
  """
  Total time and time interval are in seconds
  Raises Exception if table not updated after total time
  """
  start_time = time.time()
  time_elapsed = time.time() - start_time
  while time_elapsed < total_time:
    if get_profiledate_count(table=table,profiledate=date) > 0:
      logger.info(f"Customer profile table updated for date {date}")
      return True
    
    logger.info(f"Waiting table update for date {date}, {time_elapsed} secs of {total_time} secs elapsed")
    time.sleep(time_interval)
    time_elapsed = time.time() - start_time
  raise Exception(f"Customer profile table not updated after {total_time} seconds")

# COMMAND ----------

wait_for_updated_customer_profile(table= TRIGGER_TABLE,date= PROFILE_DATE,time_interval= TRIGGER_TIMER_INTERVAL, total_time=TRIGGER_TOTAL_TIME)

# COMMAND ----------

return_values = {
  "output": ""
}
dbutils.notebook.exit(json.dumps(return_values))