# Databricks notebook source
# MAGIC %md
# MAGIC #### Import libs and init logger

# COMMAND ----------

import logging
import json
from pyspark.sql.functions import col, lower, udf, upper, rand
from pyspark.sql.types import FloatType
import mlflow 

# COMMAND ----------

# MAGIC %run ./common_libs/parameter_utils_nb

# COMMAND ----------

# MAGIC %run ./common_libs/transformer_utils_nb

# COMMAND ----------

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("predict")  
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read input job parameters

# COMMAND ----------

input_parameter_specs = {
  "run_id": ("Run ID", "default_run_id", str.strip),
  "pipeline_name": ("Pipeline Name", "default_pipeline_name", str.strip),
  "pipeline_config_params": ("Pipeline Config Params in json string format", "{}", json.loads),
  "input": ("Inputs in json string format", "{}", json.loads)
}
input_parameters = create_input_parameters(input_parameter_specs, dbutils=dbutils)
input_parameter_values = get_input_parameter_values(input_parameters, dbutils=dbutils)

logger.info(f"Input parameters: {json.dumps(input_parameter_values, indent=4)}")

# COMMAND ----------

# Read input job parameters
RUN_ID = input_parameter_values["run_id"]
PIPELINE_NAME = input_parameter_values["pipeline_name"]
INPUT_DATA_BATCH_UUID = input_parameter_values["input"]["batch_uuid"].strip()
INPUT_DATA_TABLE = input_parameter_values["input"]["result_data_table"].strip()
TRANSFORMER_NAME = input_parameter_values["pipeline_config_params"]["prediction_pipeline_name"].strip()
TRANSFORMER_ALIAS = input_parameter_values["pipeline_config_params"]["prediction_pipeline_alias"].strip()
OUTPUT_DATA_TABLE =  input_parameter_values["pipeline_config_params"]["prediction_output_data_table"].strip()

# COMMAND ----------

logger.info("RUN_ID: %s", RUN_ID)
logger.info("PIPELINE_NAME: %s", PIPELINE_NAME)
logger.info("INPUT_DATA_BATCH_UUID: %s", INPUT_DATA_BATCH_UUID)
logger.info("INPUT_DATA_TABLE: %s", INPUT_DATA_TABLE)
logger.info("TRANSFORMER_NAME: %s", TRANSFORMER_NAME)
logger.info("TRANSFORMER_ALIAS: %s", TRANSFORMER_ALIAS)
logger.info("OUTPUT_DATA_TABLE: %s", OUTPUT_DATA_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize pipeline input/output and run

# COMMAND ----------

from mlflow import MlflowClient

class SparkTransfomerFromRegistry:
        def __init__(self, name, alias) :
                self._name = name
                mlflow.set_registry_uri('databricks-uc') 
                self._transformer = mlflow.spark.load_model(f"models:/{name}@{alias}")
                client  = MlflowClient()
                self._version = client.get_model_version_by_alias(name, alias).version

        def transform(self, data) :
                predictions = self._transformer.transform(data)
                second_element = udf(lambda v: float(v[1]), FloatType())
                predictions = predictions.withColumn("scores", second_element("probability"))   
                predictions = predictions.select(["profiledate", "customerkey", "scores"])  
                return predictions

        def get_name(self) -> str:
                return self._name

        def get_version(self) -> str:
                return self._version

########################################################################################################

def pipeline_input_data_reader():
        df = spark.sql(f"select * from {INPUT_DATA_TABLE} where batch_uuid = '{INPUT_DATA_BATCH_UUID}'")
        return df

def pipeline_output_data_writer(df):
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(OUTPUT_DATA_TABLE) 

def pipeline_registry_transformer_getter():
        return SparkTransfomerFromRegistry(TRANSFORMER_NAME, TRANSFORMER_ALIAS)

# COMMAND ----------

tranformed_data = None 
batch_uuid = "-"

transfomer_pipeline = TransformerPipeline(
  input_data_reader=pipeline_input_data_reader,
  output_data_writer=pipeline_output_data_writer,
  registry_transformer_getter=pipeline_registry_transformer_getter,      
  name = PIPELINE_NAME,
  spark_session = spark,
)
tranformed_data, batch_uuid = transfomer_pipeline.run(run_id=RUN_ID)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Return

# COMMAND ----------

output = {
  "batch_uuid": batch_uuid, 
  "result_data_table": OUTPUT_DATA_TABLE
}
return_values = {
  "output": json.dumps(output)
}
dbutils.notebook.exit(json.dumps(return_values))