# Databricks notebook source
# MAGIC %md
# MAGIC #### Import libs and init logger

# COMMAND ----------

import numpy as np
import pandas as pd
from sklearn.metrics import fbeta_score, precision_recall_curve, classification_report
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.sql.functions import col, when, udf, rand, lit
from pyspark.sql.types import FloatType, DoubleType, IntegerType, LongType, StringType, DecimalType, TimestampType, BooleanType, StructType, StructField
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from imblearn.over_sampling import SMOTE
from pyspark.ml.classification import LogisticRegression
from pyspark.sql import functions as F
from pyspark.ml.feature import Imputer, StringIndexer, OneHotEncoder
from pyspark.ml.feature import VectorAssembler
from imblearn.over_sampling import SMOTE
from pyspark.sql import SparkSession
from pyspark.sql.functions import when
from pyspark.sql import Window
from pyspark.sql.functions import row_number
from pyspark.mllib.evaluation import MulticlassMetrics, BinaryClassificationMetrics
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import warnings
import mlflow
import mlflow.spark
from mlflow.models.signature import infer_signature
import matplotlib as mpl
import matplotlib.pyplot as plt
%matplotlib inline

# COMMAND ----------

import logging
import json
from pyspark.sql.functions import col, lower, udf, upper, rand
import mlflow 

# COMMAND ----------

# MAGIC %run ./common_libs/parameter_utils_nb

# COMMAND ----------

# MAGIC %run ./common_libs/transformer_utils_nb

# COMMAND ----------

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("preprocessing")  
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read input job parameters 

# COMMAND ----------

input_parameter_specs = {
  "run_id": ("Run ID", "default_run_id", str.strip),
  "pipeline_name": ("Pipeline Name", "default_pipeline_name", str.strip),
  "pipeline_config_params": ("Pipeline Config Params", "{}", json.loads)
}
input_parameters = create_input_parameters(input_parameter_specs, dbutils=dbutils)
input_parameter_values = get_input_parameter_values(input_parameters, dbutils=dbutils)

logger.info(f"Input parameters: {json.dumps(input_parameter_values, indent=4)}")

# COMMAND ----------

RUN_ID = input_parameter_values["run_id"]
PIPELINE_NAME = input_parameter_values["pipeline_name"]
TRANSFORMER_NAME = input_parameter_values["pipeline_config_params"]["preprocessing_pipeline_name"].strip()
TRANSFORMER_ALIAS =  input_parameter_values["pipeline_config_params"]["preprocessing_pipeline_alias"].strip()
OUTPUT_DATA_TABLE =  input_parameter_values["pipeline_config_params"]["preprocessing_output_data_table"].strip()
INPUT_DATA_TABLE =  input_parameter_values["pipeline_config_params"]["input_data_table"].strip()
PROFILE_DATE = get_profile_date(input_parameter_values["pipeline_config_params"].get("profiledate", None))
INPUT_DATA_TABLE_LIMIT = input_parameter_values["pipeline_config_params"].get("input_data_table_limit", None)

# COMMAND ----------

logger.info("RUN_ID: %s", RUN_ID)
logger.info("PIPELINE_NAME: %s", PIPELINE_NAME)
logger.info("TRANSFORMER_NAME: %s", TRANSFORMER_NAME)
logger.info("TRANSFORMER_ALIAS: %s", TRANSFORMER_ALIAS)
logger.info("OUTPUT_DATA_TABLE: %s", OUTPUT_DATA_TABLE)
logger.info("INPUT_DATA_TABLE: %s", INPUT_DATA_TABLE)
logger.info("INPUT_DATA_TABLE_LIMIT: %s", INPUT_DATA_TABLE_LIMIT)
logger.info("PROFILE_DATE: %s", PROFILE_DATE)

# COMMAND ----------

select_query = f"""select * from {INPUT_DATA_TABLE}"""

customerprofile_data = spark.sql(select_query)
num_rows = customerprofile_data.count()
num_cols = len(customerprofile_data.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize pipeline input/output and run

# COMMAND ----------

from mlflow import MlflowClient

class SparkTransfomerFromRegistry:
        def __init__(self, name, alias) :
                self._name = name
                mlflow.set_registry_uri('databricks-uc') 
                self._transformer = mlflow.spark.load_model(f"models:/{name}@{alias}")
                client  = MlflowClient()
                self._version = client.get_model_version_by_alias(name, alias).version

        def transform(self, data) :
                transformed_data = self._transformer.transform(data)
                transformed_data = transformed_data.select(["profiledate", "customerkey", "features"])     
                return transformed_data

        def get_name(self) -> str:
                return self._name

        def get_version(self) -> str:
                return self._version

########################################################################################################

def pipeline_input_data_reader():
        _applicable_profiles_query = """
                select * from {table} 
                where profiledate = '{date}' 
                and LATESTLATEFEECHARGEAMOUNT>0
                and DATEDIFF(current_date(), LATESTINVOICEDATE) <= 15
                """
        query = _applicable_profiles_query.format(table=INPUT_DATA_TABLE, date=PROFILE_DATE)
        if INPUT_DATA_TABLE_LIMIT:
               query = f"{query} limit {INPUT_DATA_TABLE_LIMIT}"
        df = spark.sql(query)
        excluded_columns = ["PROFILEDATE", "LATESTLATEFEECHARGEDATE"]

        # Identify timestamp columns
        timestamp_columns = [col.name for col in df.schema.fields if isinstance(col.dataType, TimestampType)]

        # If TimestampType columns exist, remove them
        if timestamp_columns:
            df = df.drop(*timestamp_columns)

        # Identify columns for filling missing values
        column_defaults = {
            col.name: 0 if isinstance(col.dataType, (FloatType, DoubleType, IntegerType, LongType, DecimalType)) else 'NotProvided'
            for col in df.schema.fields
            if col.name not in excluded_columns
        }

        # Fill missing values for the remaining columns
        df = df.fillna(column_defaults)

        return df

def pipeline_output_data_writer(df):
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(OUTPUT_DATA_TABLE) 

def pipeline_registry_transformer_getter():
        return SparkTransfomerFromRegistry(TRANSFORMER_NAME, TRANSFORMER_ALIAS)


# COMMAND ----------

tranformed_data = None 
batch_uuid = "-"

transfomer_pipeline = TransformerPipeline(
  input_data_reader=pipeline_input_data_reader,
  output_data_writer=pipeline_output_data_writer,
  registry_transformer_getter=pipeline_registry_transformer_getter,      
  name = PIPELINE_NAME,
  spark_session = spark,
)
tranformed_data, batch_uuid = transfomer_pipeline.run(run_id=RUN_ID)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Return

# COMMAND ----------

output = { 
   "batch_uuid": batch_uuid,
   "result_data_table": OUTPUT_DATA_TABLE
  }
return_values = { 
   "output": json.dumps(output),
  }
dbutils.notebook.exit(json.dumps(return_values))