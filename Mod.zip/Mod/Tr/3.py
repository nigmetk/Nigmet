# Databricks notebook source
# Import necessary libraries
import numpy as np
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql.functions import col, when
from pyspark.sql.types import FloatType, DoubleType, IntegerType, LongType, StringType, DecimalType, TimestampType, BooleanType, StructType, StructField, DateType
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from imblearn.over_sampling import SMOTE
from pyspark.sql.functions import col, rand, lit
from pyspark.ml.classification import LogisticRegression
from pyspark.sql import functions as F
from pyspark.ml.feature import Imputer, StringIndexer, OneHotEncoder
from pyspark.ml.feature import VectorAssembler
from imblearn.over_sampling import SMOTE
from pyspark.sql import SparkSession
from pyspark.sql.functions import when
from pyspark.sql import Window
from pyspark.sql.functions import row_number
from pyspark.mllib.evaluation import MulticlassMetrics, BinaryClassificationMetrics
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import warnings
import mlflow
import mlflow.spark


# Initialize SparkSession
spark = SparkSession.builder.appName('Late_Fee_Prediction').getOrCreate()

def preprocess_data(data):
    # Preprocessing steps:
    # Define the columns to be excluded from filling missing values
    excluded_columns = ["PROFILEDATE", "LATESTLATEFEECHARGEDATE"]

    # Identify timestamp columns
    timestamp_columns = [col.name for col in data.schema.fields if isinstance(col.dataType, TimestampType)]

    # If TimestampType columns exist, remove them
    if timestamp_columns:
        data = data.drop(*timestamp_columns)

    # Identify columns for filling missing values
    column_defaults = {
        col.name: 0 if isinstance(col.dataType, (FloatType, DoubleType, IntegerType, LongType, DecimalType)) else 'NotProvided'
        for col in data.schema.fields
        if col.name not in excluded_columns
    }

    # Replace NaN with None in string columns (excluding the specified date columns)
    for col_name in column_defaults:
        if column_defaults[col_name] == 'NotProvided':
            data = data.withColumn(col_name, F.when(F.isnan(F.col(col_name)), None).otherwise(F.col(col_name)))

    # Fill missing values for the remaining columns
    df_cleaned = data.fillna(column_defaults)

    # Replace the values in the 'SUBTOPIC' column
    df_cleaned = df_cleaned.withColumn(
        "SUBTOPIC",
        when(df_cleaned["SUBTOPIC"] == "late_fee", "late_fee_topic")
        .otherwise("No_late_fee_topic")
    )

    # Dropping mandatory columns
    dropping_columns = ["REGULARPLANEXPIREDDATE", "LATESTINVOICEPAYMENTDUEDATE", "LATESTAUTOPAYMETHODCHANGEDATE","CUSTOMERSTATUSCHANGEDATE", "LATESTAUTOPAYSTARTDATE", "REGULARPLANADDEDDATE", "AUTOPAYCANCELATIONDATE", "AUTOPAYFIRSTSTARTDATE", "LATESTPAYMENTARRANGEMENTSTARTDATE", "COLLECTIONSTARTDATE", "LATESTPAYMENTDATE", "LATESTUSEDPAYMENTMETHODCHANGEDATE","LATESTINVOICECONFIRMEDDATE", "LATESTADJUSTMENTDATE", "LATESTINVOICEDATE","LATESTADDRESSCHANGEDATE", "LATESTCAREBILLINTERACTIONDATE", "LATESTACTIVATIONOCDATE","DEVICEADDEDDATE", "LATESTSUBSCRIBERACTIVATIONDATE", "LATESTPAYMENTARRANGEMENTENDDATE","LATESTCAREINTERACTIONDATE", "LATESTCAREREVIEWBILLINTERACTIONDATE", "PREVIOUSINVOICERUNDATE","LATESTSUBSCRIBERCANCELATIONDATE", "LATESTSIGNIFICANTUCDATE", "PREVIOUSINVOICECLOSEDATE","LATESTINVOICECLOSEDATE", "LATESTINVOICERUNDATE", "NEXTINVOICELASTDATAPASSDATE_N","LATESTINVOICELASTDATAPASSDATE", "LATESTUNBILLEDROAMINGCHARGEDATE", "LATESTDATAPASSDATE","LATESTRESTORESUBSCRIBERDATE", "DEVICEEXPIREDDATE", "LATESTSUBSCRIBERSUSPENDEDDATE", "LATESTINVOICEFIRSTROAMINGCHARGEDATE","LATESTAUTOPAYKICKBACKDATE", "LATESTPAKICKBACKDATE", "FIRSTUNBILLEDROAMINGCHARGEDATE","PROMOTIONALSOCEXPIREDDATE", "COLLECTIONENDDATE", "SPRINTCONVERSIONDATE","LATESTREESTABLISHSUBSCRIBERDATE", "LATESTBILLCYCLECHANGEEFFECTIVEDATE", "SPRINTMIGRATIONDATE","LATESTCAREINTERACTIONPAYMENTARRANGEMENTDATE", "LATESTBROKENPAYMENTARRANGEMENTDATE","LATESTADJUSTMENTREVERSALDATE", "LATESTLINERESTORATIONFEEDATE", "LATESTBILLCYCLECHANGEISSUEDATE","LATESTBROKENDEVICECONTRACTCHARGEDATE", "LATESTINVOICELATESTROAMINGCHARGEDATE","NEXTINVOICELASTDATAPASSDATE", "LATESTAUTOPAYREMOVALREASONDESC","LATESTINVOICEDEVICEREVERSALADJUSTMENTSPERCENTAGECHANGE", "ACCOUNTACTIVATIONDATE", "CUSTOMER_INTENT", "LLM_RESPONSE","CUSTOMERSTATUSREASONCODEDESC", "COLLECTIONSTAGE", "L2INTENT", "LATESTCAREINTERACTIONSUBCATEGORYDESC", "LATESTCAREINTERACTIONCATEGORYDESC", "LATESTAUTOPAYREMOVALREASONDESC", "LATESTINVOICEDEVICEREVERSALADJUSTMENTSPERCENTAGECHANGE","LATEFEE_FLAG", "CUSTOMERTYPEKEY", "LATESTUSEDPAYMENTMETHODCHANGEDDATE","PROPENSITY_TO_CALL_NEXT_MONTH_LABEL","LATESTTHREECYCLESCAREBILLINGINTERACTIONCOUNT","PROPENSITY_TO_CALL_NEXT_MONTH_SCORE","CUSTOMERSUBTYPEKEY"]

    # Select the columns to keep
    keeping_columns = [col for col in df_cleaned.columns if col not in dropping_columns]
    df_selected = df_cleaned.select(keeping_columns)

    # Feature selection
    Selected_Features = [
    'COLLECTIONS3MCOUNT',
    'CUSTOMERCOLLECTION12MPAYMENT',
    'CAREBILLINGINTERACTION1MCOUNT',
    'COLLECTIONAMOUNT',
    'INVOICEAVERAGE3MAMOUNT',
    'LATESTINVOICETOTALAMOUNT',
    'TOTALADJUSTMENT3MAMOUNT',
    'CAREACCOUNTINTERACTION1MCOUNT',
    'PREVIOUSINVOICETOTALAMOUNT',
    'CAREOTHERINTERACTION1MCOUNT',
    'AVERAGE3MPREVIOUSINVOICETOTALOCAMOUNT',
    'COLLECTIONFLAG',
    'COLLECTIONS12MCOUNT',
    'CBX_SCORE',
    'LATESTPAKICKBACKAMOUNT',
    'LATESTLATEFEECHARGEAMOUNT',
    'CUSTOMERTENURE',
    'LATESTINVOICENETCHARGEAMOUNT',
    'LATESTINVOICENONUCCHARGEAMOUNT',
    'PREVIOUSINVOICEPREVIOUSCYCLEAMOUNT',
    'LATESTADJUSTMENTAMOUNT',
    'LATESTCUSTOMERINVOICERCCHANGEDFLAG',
    'LATESTINVOICETOTALADJUSTMENTSLASTCYCLEPERCENTAGECHANGE',
    'LASTCAREINTERACTIONCALLDURATION',
    'TOTALCANCELLEDSUBSCRIPTIONCOUNT',
    'TOTALADJUSTMENT3MCOUNT',
    'LATESTCUSTOMERINVOICEOCCHANGEDFLAG',
    'PREVIOUSINVOICETOTALOCAMOUNT',
    'LATESTINVOICEINCREASECYCLEAMOUNT',
    'PREVIOUSINVOICETOTALRCAMOUNT',
    'LATESTCUSTOMERINVOICETOTALRCAMOUNT',
    'DEVICEEXPIREDDAYSCOUNT',
    'TOTALINTERACTION1MCOUNT',
    'LATESTINVOICETOTALADJUSTMENTSPERCENTAGECHANGE',
    'LATEFEE1MCHARGEAMOUNT',
    'LATESTINVOICETOTALPERCENTAGECHANGE',
    'LATESTINVOICENONUCCHARGELASTCYCLEPERCENTAGECHANGE',
    'LATESTINVOICETOTALLASTCYCLEPERCENTAGECHANGE',
    'AVERAGE3MPREVIOUSINVOICETOTALRCAMOUNT',
    'LATESTCUSTOMERINVOICETOTALCREDITAMOUNT',
    'LATESTINVOICECYCLEAMOUNTPERCENTAGECHANGE',
    'LATESTINVOICENONUCCHARGEPERCENTAGECHANGE',
    'LATESTINVOICENETCHARGELASTCYCLEPERCENTAGECHANGE',
    'LATESTINVOICENETCHARGEPERCENTAGECHANGE',
    'LATESTCUSTOMERINVOICETOTALOCAMOUNT',
    'LATESTCUSTOMERINVOICETOTALPAYMENTAMOUNT',
    'LATESTINVOICETAXCHARGEAMOUNT',
    'TOTALBROKENPAYMENTARRANGEMENTCOUNT',
    'LATESTINVOICERCPERCENTAGECHANGE',
    'LATESTINVOICETAXCHARGEPERCENTAGECHANGE',
    'LATESTINVOICERCLASTCYCLEPERCENTAGECHANGE',
    'LATESTINVOICEDEVICECHARGESAMOUNT',
    'LATESTINVOICETAXCHARGELASTCYCLEPERCENTAGECHANGE',
    'PREVIOUSINVOICEDEVICECHARGESAMOUNT',
    'LATESTINVOICETOTALADJUSTMENTSTAXPERCENTAGECHANGE',
    'LATESTINVOICETOTALADJUSTMENTSTAXAMOUNT',
    'LATESTINVOICETOTALADJUSTMENTSTAXLASTCYCLEPERCENTAGECHANGE',
    'CUSTOMERPAYMENT3MAVERAGECOUNT',
    'LATESTINVOICEDEVICEADJUSTMENTSAMOUNT',
    'PREVIOUSINVOICEDEVICEADJUSTMENTSAMOUNT',
    'REGULARSOC1MEXPIREDFLAG',
    'TOTALACTIVESUBSCRIPTIONCOUNT',
    'LATESTLINERESTORATIONFEEAMOUNT',
    'LATESTAUTOPAYKICKBACKAMOUNT',
    'LATESTINVOICEDEVICECHARGEPERCENTAGECHANGE',
    'REGULARPLANCHANGE3MCOUNT',
    'CUSTOMERPAYMENT1MTOTALCOUNT',
    'PREVIOUSINVOICEAUTOPAYPAYMENTFLAG',
    'INTERACTION1MBEFORELATESTCONFDATEFLAG',
    'CUSTOMERCOHORTIND',
    'CUSTOMERKEY',
    'PROFILEDATE',
    'LATESTLATEFEECHARGEDATE',
    'SUBTOPIC']

    available_columns = df_selected.columns
    # Filter out the columns that exist in df_selected from Selected_Features
    valid_columns = [col for col in Selected_Features if col in available_columns]
    # Selecting only the columns that exist
    df_Final_selected = df_selected.select(*valid_columns)

    # Calculate the ratio of majority to minority class
    major_df = df_Final_selected.filter(col("SUBTOPIC") == "No_late_fee_topic")
    minor_df = df_Final_selected.filter(col("SUBTOPIC") == "late_fee_topic")
    ratio = major_df.count() / minor_df.count()
    # Oversample the minority class to match the number of samples in the majority class
    oversampled_minor_df = minor_df.sample(withReplacement=True, fraction=ratio, seed=42)
    # Combine oversampled minority class DataFrame with majority class DataFrame
    balanced_df = major_df.unionAll(oversampled_minor_df)

    return balanced_df