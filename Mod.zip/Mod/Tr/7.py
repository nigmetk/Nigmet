﻿# Databricks notebook source
# MAGIC %md
# MAGIC ####Author: Anik Mukhopadhyay
# MAGIC - ####Late fee Intent prediction binary classifcation model 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Preprocessing

# COMMAND ----------

import numpy as np
import pandas as pd
from sklearn.metrics import fbeta_score, precision_recall_curve, classification_report
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.sql.functions import col, when, udf, rand, lit
from pyspark.sql.types import FloatType, DoubleType, IntegerType, LongType, StringType, DecimalType, TimestampType, BooleanType, StructType, StructField
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from imblearn.over_sampling import SMOTE
from pyspark.ml.classification import LogisticRegression
from pyspark.sql import functions as F
from pyspark.ml.feature import Imputer, StringIndexer, OneHotEncoder
from pyspark.ml.feature import VectorAssembler
from imblearn.over_sampling import SMOTE
from pyspark.sql import SparkSession
from pyspark.sql.functions import when
from pyspark.sql import Window
from pyspark.sql.functions import row_number
from pyspark.mllib.evaluation import MulticlassMetrics, BinaryClassificationMetrics
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import warnings
import mlflow
import mlflow.spark
from mlflow.models.signature import infer_signature
import matplotlib as mpl
import matplotlib.pyplot as plt
%matplotlib inline

# COMMAND ----------

# Initialize SparkSession
spark = SparkSession.builder.appName('Late_Fee_Prediction').getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC - ####MLFLOW starting point

# COMMAND ----------

mlflow.set_registry_uri('databricks-uc')

# COMMAND ----------

# mlflow.set_experiment("/Workspace/ETL_BDI11/Notebooks/GL_ML_Models/Anik/LateFee_Intent_MLFlow/LateFee_Model_Dev")

# COMMAND ----------

# # Set the experiment name
# experiment_name = "/ETL_BDI11/Notebooks/GL_ML_Models/Anik/LateFee_Intent_MLFlow/LateFee_Model_Dev"

# # Set the experiment
# mlflow.set_experiment(experiment_name)

# COMMAND ----------

select_query = f"""select * from devrzrcore.bdidb.latefee_intent_model_v2"""

data = spark.sql(select_query)

# COMMAND ----------

num_rows = data.count()
num_cols = len(data.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT CUSTOMERKEY,count(*) FROM devrzrcore.bdidb.latefee_intent_model_v2
# MAGIC GROUP BY CUSTOMERKEY
# MAGIC HAVING count(*)>1

# COMMAND ----------

# Check if TimestampType columns exist
timestamp_columns = [col.name for col in data.schema.fields if isinstance(col.dataType, TimestampType)]

# If TimestampType columns exist, remove them
if timestamp_columns:
    data = data.drop(*timestamp_columns)

# Replace null values in the DataFrame
# Replace null values in numerical columns with 0 and categorical (string) columns with an NotProvided string
column_defaults = {
    col.name: 0 if isinstance(col.dataType, (FloatType, DoubleType, IntegerType, LongType, DecimalType)) else 'NotProvided'
    for col in data.schema.fields
}
df_cleaned = data.fillna(column_defaults)

# Display the cleaned DataFrame
df_cleaned.display()

# COMMAND ----------

from pyspark.sql import functions as F

def check_missing_values(data):
    '''
    Returns a DataFrame that contains information about missing values in each column of the given DataFrame.
    It provides the count and percentage of missing values in each column.
    '''
    # Total number of rows in the DataFrame
    total_rows = data.count()
    
    # Initialize a list to store missing value information for each column
    missing_info = []
    
    # Iterate through each column in the DataFrame
    for col in data.columns:
        # Count the number of null values in the column
        null_count = data.filter(F.col(col).isNull()).count()
        
        # Calculate the percentage of null values
        null_percentage = (null_count / total_rows) * 100
        
        # Store the information in the list
        missing_info.append({
            'Col_name': col,
            'Count_Nulls': null_count,
            'Percentage_Nulls': null_percentage
        })
    
    # Convert the list of dictionaries to a DataFrame
    missing_df = spark.createDataFrame(missing_info)
    
    # Sort the DataFrame by 'Count_Nulls' in descending order
    missing_df = missing_df.sort(F.desc('Count_Nulls'))
    
    return missing_df

# Use the function to check missing values in the cleaned DataFrame
missing_values_df = check_missing_values(df_cleaned)

# Display the missing values DataFrame
missing_values_df.show()

# COMMAND ----------

df_cleaned = df_cleaned.withColumn(
    "SUBTOPIC",
    when(df_cleaned["SUBTOPIC"] == "late_fee", "late_fee_topic")
    .otherwise("No_late_fee_topic")
)

df_counts = df_cleaned.groupBy("SUBTOPIC").count()
# Show the result
df_counts.show()

# COMMAND ----------

# MAGIC %md
# MAGIC - ####Dropping Non relatable columns

# COMMAND ----------

dropping_columns = ["REGULARPLANEXPIREDDATE", "LATESTINVOICEPAYMENTDUEDATE", "LATESTAUTOPAYMETHODCHANGEDATE","CUSTOMERSTATUSCHANGEDATE", "LATESTAUTOPAYSTARTDATE", "REGULARPLANADDEDDATE", "AUTOPAYCANCELATIONDATE", "AUTOPAYFIRSTSTARTDATE", "LATESTPAYMENTARRANGEMENTSTARTDATE", "COLLECTIONSTARTDATE", "LATESTPAYMENTDATE", "LATESTUSEDPAYMENTMETHODCHANGEDATE","LATESTINVOICECONFIRMEDDATE", "LATESTADJUSTMENTDATE", "LATESTINVOICEDATE","LATESTADDRESSCHANGEDATE", "LATESTCAREBILLINTERACTIONDATE", "LATESTACTIVATIONOCDATE","DEVICEADDEDDATE", "LATESTSUBSCRIBERACTIVATIONDATE", "LATESTPAYMENTARRANGEMENTENDDATE","LATESTCAREINTERACTIONDATE", "LATESTCAREREVIEWBILLINTERACTIONDATE", "PREVIOUSINVOICERUNDATE","LATESTSUBSCRIBERCANCELATIONDATE", "LATESTSIGNIFICANTUCDATE", "PREVIOUSINVOICECLOSEDATE","LATESTINVOICECLOSEDATE", "LATESTINVOICERUNDATE", "NEXTINVOICELASTDATAPASSDATE_N","LATESTINVOICELASTDATAPASSDATE", "LATESTUNBILLEDROAMINGCHARGEDATE", "LATESTDATAPASSDATE","LATESTLATEFEECHARGEDATE", "LATESTRESTORESUBSCRIBERDATE", "DEVICEEXPIREDDATE", "LATESTSUBSCRIBERSUSPENDEDDATE", "LATESTINVOICEFIRSTROAMINGCHARGEDATE","LATESTAUTOPAYKICKBACKDATE", "LATESTPAKICKBACKDATE", "FIRSTUNBILLEDROAMINGCHARGEDATE","PROMOTIONALSOCEXPIREDDATE", "COLLECTIONENDDATE", "SPRINTCONVERSIONDATE","LATESTREESTABLISHSUBSCRIBERDATE", "LATESTBILLCYCLECHANGEEFFECTIVEDATE", "SPRINTMIGRATIONDATE","LATESTCAREINTERACTIONPAYMENTARRANGEMENTDATE", "LATESTBROKENPAYMENTARRANGEMENTDATE","LATESTADJUSTMENTREVERSALDATE", "LATESTLINERESTORATIONFEEDATE", "LATESTBILLCYCLECHANGEISSUEDATE","LATESTBROKENDEVICECONTRACTCHARGEDATE", "LATESTINVOICELATESTROAMINGCHARGEDATE","NEXTINVOICELASTDATAPASSDATE", "LATESTAUTOPAYREMOVALREASONDESC","LATESTINVOICEDEVICEREVERSALADJUSTMENTSPERCENTAGECHANGE", "ACCOUNTACTIVATIONDATE", "CUSTOMER_INTENT", "LLM_RESPONSE","CUSTOMERSTATUSREASONCODEDESC", "COLLECTIONSTAGE", "L2INTENT", "LATESTCAREINTERACTIONSUBCATEGORYDESC", "LATESTCAREINTERACTIONCATEGORYDESC", "LATESTAUTOPAYREMOVALREASONDESC", "LATESTINVOICEDEVICEREVERSALADJUSTMENTSPERCENTAGECHANGE","LATEFEE_FLAG", "CUSTOMERTYPEKEY", "LATESTUSEDPAYMENTMETHODCHANGEDDATE","PROPENSITY_TO_CALL_NEXT_MONTH_LABEL","LATESTTHREECYCLESCAREBILLINGINTERACTIONCOUNT","PROPENSITY_TO_CALL_NEXT_MONTH_SCORE","CUSTOMERSUBTYPEKEY"]

# COMMAND ----------

# Other6Cols = ['ROAMINGCHARGE2MFLAG_O', 'DEVICE1MADDEDFLAG', 'AUTOPAYREMOVALAFTERLASTINVOICEFLAG', 'UCINCREASEFLAG', 'LATESTINVOICEABNORMALHIGHFLAG', 'INTERACTIONAFTERLATESTCONFDATEDAYSCOUNT']

# # Check if the column exists in the dataframe
# existing_columns = df_cleaned.columns

# # Separate FLAG related columns and other columns
# flag_columns = [col_name for col_name in Other6Cols if 'FLAG' in col_name and col_name in existing_columns]
# other_columns = [col_name for col_name in Other6Cols if col_name not in flag_columns and col_name in existing_columns]

# # Cast FLAG columns to integer and other columns to double
# df_casted = df_cleaned.select(
#     *[col(col_name).cast('int').alias(col_name) for col_name in flag_columns],
#     *[col(col_name).cast('double').alias(col_name) for col_name in other_columns],
#     *[col_name for col_name in existing_columns if col_name not in flag_columns and col_name not in other_columns]
# )
# df_casted.printSchema()

# COMMAND ----------

# Select the columns to keep
keeping_columns = [col for col in df_cleaned.columns if col not in dropping_columns]

# Select the desired columns
df_selected = df_cleaned.select(keeping_columns)

# Validate changes
num_rows = df_selected.count()
num_cols = len(df_selected.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# MAGIC %md
# MAGIC - ####Final selected features

# COMMAND ----------

Selected_Features_95 =  ['SUBTOPIC','LATESTINVOICEINCREASECYCLEAMOUNT', 'LATESTINVOICEAUTOPAYDISCOUNTAMOUNT', 'LATESTINVOICETAXCHARGEAMOUNT', 'LATESTADJUSTMENTAMOUNT', 'PREVIUSINVOICEDEVICECHARGESAMOUNT', 'AVERAGE3MPREVIOUSINVOICETOTALRCAMOUNT', 'CUSTOMERTENURE', 'LATESTINVOICETAXCHARGELASTCYCLEPERCENTAGECHANGE', 'LATESTINVOICENETCHARGELASTCYCLEPERCENTAGECHANGE', 'LATESTINVOICECYCLEAMOUNTPERCENTAGECHANGE', 'LATESTINVOICETAXCHARGEPERCENTAGECHANGE', 'LATESTINVOICETOTALLASTCYCLEPERCENTAGECHANGE', 'INVOICEAVERAGE3MAMOUNT', 'LATESTINVOICETOTALADJUSTMENTSLASTCYCLEPERCENTAGECHANGE', 'LATESTINVOICETOTALAMOUNT', 'LATESTINVOICEDEVICECHARGESAMOUNT', 'LATESTINVOICETOTALADJUSTMENTSTAXAMOUNT', 'DEVICEEXPIREDDAYSCOUNT', 'CUSTOMERCOLLECTION12MPAYMENT', 'LATESTCUSTOMERINVOICETOTALCREDITAMOUNT', 'LATESTINVOICENONUCCHARGEPERCENTAGECHANGE', 'LATESTINVOICERCLASTCYCLEPERCENTAGECHANGE', 'CAREOTHERINTERACTION1MCOUNT', 'LATESTCUSTOMERINVOICETOTALOCAMOUNT', 'TOTALADJUSTMENT3MAMOUNT', 'LATESTINVOICELASTCYCLEAMOUNT', 'LATESTINVOICETOTALADJUSTMENTSPERCENTAGECHANGE', 'TOTALACTIVESUBSCRIPTIONCOUNT', 'LATESTCUSTOMERINVOICERCCHANGEDFLAG', 'LATESTINVOICENETCHARGEAMOUNT', 'LATESTINVOICEPAIDFLAG', 'LATESTCUSTOMERINVOICETOTALPAYMENTAMOUNT', 'TOTALINTERACTION1MCOUNT', 'LATESTAUTOPAYKICKBACKAMOUNT', 'LATESTCUSTOMERINVOICETOTALRCAMOUNT', 'COLLECTIONAMOUNT', 'LATESTINVOICERCPERCENTAGECHANGE', 'LATESTINVOICEDEVICEADJUSTMENTSAMOUNT', 'LATESTINVOICEAUTOPAYPAYMENTFLAG', 'CAREACCOUNTINTERACTION1MCOUNT', 'COLLECTIONS3MCOUNT', 'LATESTINVOICETOTALADJUSTMENTSTAXLASTCYCLEPERCENTAGECHANGE', 'LATESTINVOICETOTALADJUSTMENTSTAXPERCENTAGECHANGE', 'LATESTCUSTOMERINVOICEOCCHANGEDFLAG', 'CBX_SCORE', 'PREVIOUSINVOICEDEVICEADJUSTMENTSAMOUNT', 'AVERAGE3MPREVIOUSINVOICETOTALOCAMOUNT', 'LATESTPAKICKBACKAMOUNT', 'LINERESTORATION1MFEEAMOUNT', 'INTERACTION1MBEFORELATESTCONFDATEFLAG', 'COLLECTIONFLAG', 'PREVIOUSINVOICEAUTOPAYDISCOUNTAMOUNT', 'PREVIOUSINVOICETOTALAMOUNT', 'TOTALBROKENPAYMENTARRANGEMENTCOUNT', 'TOTALADJUSTMENT3MCOUNT', 'PREVIOUSINVOICEAUTOPAYPAYMENTFLAG', 'CUSTOMERPAYMENT3MAVERAGECOUNT', 'COLLECTIONS12MCOUNT', 'TOTALCANCELLEDSUBSCRIPTIONCOUNT', 'PREVIOUSINVOICETOTALOCAMOUNT', 'LATESTLATEFEECHARGEAMOUNT', 'CUSTOMERPAYMENT1MTOTALCOUNT', 'CAREBILLINGINTERACTION1MCOUNT', 'LATEFEE1MCHARGEAMOUNT','SUSPENDEDCOLLECTION1MFLAG', 'LATESTLINERESTORATIONFEEAMOUNT', 'AUTOPAYDISCOUNTELIGIBILITYFLAG', 'CUSTOMERSTATUSCHANGED1MFLAG', 'REGULARSOC1MEXPIREDFLAG', 'CUSTOMERPASTDUEINVOICEFLAG', 'PREVIOUSINVOICEAUTOPAYFLAG', 'USEDPAYMENTMETHODCHANGEDLATESTCYCLEFLAG','LATESTINVOICEABNORMALHIGHBILLSHOCKFLAG','LATESTADJUSTMENTREVERSALAMOUNT', 'LATESTSIGNIFICANTUCAMOUNT', 'CHARGEABNORMALHIGHNOTCAUSINGINVOICEABNORMALHIGHFLAG', 'LATESTINVOICEVOICECHARGEPERCENTAGECHANGE', 'LATESTINVOICEUCLASTCYCLEPERCENTAGECHANGE', 'REGULARPLAN1MADDEDFLAG', 'LATESTINVOICELASTCYCLEAMOUNTINCREASEDFLAG', 'DEVICE1MEXPIREDFLAG', 'TOTALUCCHARGEAFTERLASTCYCLEAMOUNT', 'TOTALINTERACTION7DCOUNT', 'LATESTINVOICEDEVICECHARGELASTCYCLEPERCENTAGECHANGE', 'LATESTCUSTOMERINVOICETOTALUCAMOUNT', 'REGULARPLANCHANGE3MCOUNT','ROAMINGCHARGE2MFLAG_O', 'DEVICE1MADDEDFLAG', 'AUTOPAYREMOVALAFTERLASTINVOICEFLAG', 'UCINCREASEFLAG', 'LATESTINVOICEABNORMALHIGHFLAG', 'INTERACTIONAFTERLATESTCONFDATEDAYSCOUNT','VOLUNTARYAUTOPAYREMOVALFLAG', 'CUSTOMERCOHORTIND','PREVIOUSAUTOPAYMETHODIND','CUSTOMERKEY','PROFILEDATE','BAN']

# COMMAND ----------

# Get the list of available columns in df_selected DataFrame
available_columns = df_selected.columns

# Filter out the columns that exist in df_selected from Selected_Features_96
valid_columns = [col for col in Selected_Features_95 if col in available_columns]

# Selecting only the columns that exist
df_Final_selected = df_selected.select(*valid_columns)

# Validate changes
num_rows = df_Final_selected.count()
num_cols = len(df_Final_selected.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# Retrieve the schema of the DataFrame
schema = df_Final_selected.schema

# Initialize lists and counters for numerical and categorical columns
numerical_columns = []
categorical_columns = []
num_numerical_columns = 0
num_categorical_columns = 0

# Define a set of numerical data types
numerical_types = {IntegerType, LongType, DoubleType, FloatType,DecimalType, TimestampType}

# Define a set of categorical data types
categorical_types = {StringType, BooleanType}

# Iterate through the schema to identify and count the columns
for field in schema.fields:
    # Check the data type of each column
    if type(field.dataType) in numerical_types:
        numerical_columns.append(field.name)
        num_numerical_columns += 1
    elif type(field.dataType) in categorical_types:
        categorical_columns.append(field.name)
        num_categorical_columns += 1

# Display the list and count of numerical and categorical columns
print(f"List of numerical columns: {numerical_columns}")
print(f"Number of numerical columns: {num_numerical_columns}")
print(f"List of categorical columns: {categorical_columns}")
print(f"Number of categorical columns: {num_categorical_columns}")

# COMMAND ----------

['CUSTOMERKEY', 'PROFILEDATE', 'PREVIOUSAUTOPAYMETHODIND', 'PAYMENTARRANGEMENTSTATUSIND', 'LATESTSUBSCRIBERSTATUSIND', 'LATESTCAREINTERACTIONMEDIATYPE', 'CHARGEABNORMALHIGHTYPEIND', 'AUTOPAYPAYMENTMETHODIND', 'AUTOPAYCARDTYPEIND', 'CUSTOMERPREVIOUSSTATUS', 'LATESTSIGNIFICANTUCDESC', 'CUSTOMERCHURNTYPEDESC', 'LATESTCAREINTERACTIONDIRECTION', 'PREVIOUSINVOICELASTDATAPASSDESC', 'CUSTOMERCOHORTIND', 'SUBTOPIC', 'llm_response', 'VOLUNTARYAUTOPAYREMOVALFLAG']

# COMMAND ----------

#df_Final_selected.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #Balanced the Imbalanced Data

# COMMAND ----------

# Calculate the ratio of majority to minority class
major_df = df_Final_selected.filter(col("SUBTOPIC") == "No_late_fee_topic")
minor_df = df_Final_selected.filter(col("SUBTOPIC") == "late_fee_topic")
ratio = major_df.count() / minor_df.count()

# Oversample the minority class to match the number of samples in the majority class
oversampled_minor_df = minor_df.sample(withReplacement=True, fraction=ratio, seed=42)

# Combine oversampled minority class DataFrame with majority class DataFrame
balanced_df = major_df.unionAll(oversampled_minor_df)
df_counts = balanced_df.groupBy("SUBTOPIC").count()

# Show the result
df_counts.show()

# COMMAND ----------

# Retrieve the schema of the DataFrame
schema = balanced_df.schema

# Initialize lists and counters for numerical and categorical columns
numerical_columns = []
categorical_columns = []
num_numerical_columns = 0
num_categorical_columns = 0

# Define a set of numerical data types
numerical_types = {IntegerType, LongType, DoubleType, FloatType,DecimalType, TimestampType}

# Define a set of categorical data types
categorical_types = {StringType, BooleanType}

# Iterate through the schema to identify and count the columns
for field in schema.fields:
    # Check the data type of each column
    if type(field.dataType) in numerical_types:
        numerical_columns.append(field.name)
        num_numerical_columns += 1
    elif type(field.dataType) in categorical_types:
        categorical_columns.append(field.name)
        num_categorical_columns += 1

# Display the list and count of numerical and categorical columns
print(f"List of numerical columns: {numerical_columns}")
print(f"Number of numerical columns: {num_numerical_columns}")
print(f"List of categorical columns: {categorical_columns}")
print(f"Number of categorical columns: {num_categorical_columns}")

# COMMAND ----------

balanced_df.display()
num_rows = balanced_df.count()
num_cols = len(balanced_df.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# MAGIC %md
# MAGIC #Encoding and Vector Assembler

# COMMAND ----------

# Convert Binary Categorical Features (late_fee_topic/No_late_fee_topic) to 0/1
df_updated = balanced_df.withColumn("SUBTOPIC", F.when(col("SUBTOPIC") == "late_fee_topic", 1).otherwise(0))

# COMMAND ----------

# Separate categorical and numerical columns
categorical_cols = [col_name for col_name in df_updated.columns 
                    if df_updated.schema[col_name].dataType == StringType() 
                    and col_name not in ["CUSTOMERKEY", "PROFILEDATE", "BAN"]]
timestamp_cols = [col_name for col_name in df_updated.columns 
                  if df_updated.schema[col_name].dataType == TimestampType()]
numerical_cols = [col_name for col_name in df_updated.columns 
                  if df_updated.schema[col_name].dataType 
                  in [FloatType(), DoubleType(), IntegerType(), LongType(), DecimalType()]]

decimal_cols = [col_name for col_name, col_type in df_updated.dtypes if 'decimal' in col_type]                 

# Apply StringIndexer and OneHotEncoder to categorical columns
indexers = [StringIndexer(inputCol=col_name, outputCol=col_name + "_indexed", handleInvalid='keep') 
            for col_name in categorical_cols]
encoders = [OneHotEncoder(inputCol=col_name + "_indexed", outputCol=col_name + "_encoded") 
            for col_name in categorical_cols]

# Combine indexers and encoders into a single list
stages = indexers + encoders


feature_columns = [col_name + "_encoded" for col_name in categorical_cols] + numerical_cols + timestamp_cols + \
                  decimal_cols

# Exclude the target column
feature_columns.remove("SUBTOPIC")
feature_columns.remove("BAN")

# Assemble all encoded features along with numerical features into a single feature vector
#assembler = VectorAssembler(inputCols=[col_name + "_encoded" for col_name in categorical_cols] 
                            #+ numerical_cols, outputCol="features")

assembler = VectorAssembler(inputCols= feature_columns , outputCol="features")                           

# Combine all stages into a single pipeline
pipeline = Pipeline(stages=stages + [assembler])

# Fit and transform the pipeline
transformed_df = pipeline.fit(df_updated).transform(df_updated)

# COMMAND ----------

#transformed_df.display()
feature_columns

# COMMAND ----------

# Split the data into training and test sets
(train_data, test_data) = transformed_df.randomSplit([0.8, 0.2], seed=42)

# COMMAND ----------

# Validate changes
num_rows = train_data.count()
num_cols = len(train_data.columns)
num_rows2 = test_data.count()
num_cols2 = len(test_data.columns)
print(f"Number of rows in train_data: {num_rows}")
print(f"Number of columns in train_data: {num_cols}")
print(f"Number of rows in test_data: {num_rows2}")
print(f"Number of columns in test_data: {num_cols2}")

# COMMAND ----------

# Initialize Random Forest Classifier
rf = RandomForestClassifier(labelCol="SUBTOPIC", featuresCol="features", seed=42)

# Hyperparameter tuning with ParamGridBuilder
param_grid = ParamGridBuilder() \
    .addGrid(rf.numTrees, [150]) \
    .addGrid(rf.maxDepth, [12]) \
    .addGrid(rf.minInstancesPerNode, [10]) \
    .build()

# Cross-validation for model tuning
crossval = CrossValidator(estimator=rf, 
                          estimatorParamMaps=param_grid, 
                          evaluator=MulticlassClassificationEvaluator(labelCol="SUBTOPIC", metricName="f1"), 
                          numFolds=3)

# Run cross-validation, and choose the best set of parameters
cvModel = crossval.fit(train_data)
# Get best model from CrossValidator
best_model = cvModel.bestModel

# Print the best parameters found
print("Best parameters:")
print("numTrees:", best_model.getNumTrees)
print("maxDepth:", best_model.getMaxDepth())
print("minInstancesPerNode:", best_model.getMinInstancesPerNode())
print("minInfoGain:", best_model.getMinInfoGain())
print("subsamplingRate:", best_model.getSubsamplingRate())

# COMMAND ----------

# Evaluate the model on train data
train_predictions = best_model.transform(train_data)
train_metrics = MulticlassMetrics(train_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))

# Calculate metrics for each label
train_accuracy = train_metrics.accuracy
train_precision = train_metrics.precision(label=1)  # Precision for label 1
train_recall = train_metrics.recall(label=1)  # Recall for label 1
train_f1_score = train_metrics.fMeasure(float(1))  # F1-score for label 1
train_f05_score = train_metrics.fMeasure(beta=0.5, label=float(1))  # F0.5-score for label 1

# AUC-ROC calculation requires BinaryClassificationMetrics
train_binary_metrics = BinaryClassificationMetrics(train_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))
train_auc_roc = train_binary_metrics.areaUnderROC

# Repeat the same for test data
# Evaluate the model on test data
test_predictions = best_model.transform(test_data)
test_metrics = MulticlassMetrics(test_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))

# Calculate metrics for each label
test_accuracy = test_metrics.accuracy
test_precision = test_metrics.precision(label=1)  # Precision for label 1
test_recall = test_metrics.recall(label=1)  # Recall for label 1
test_f1_score = test_metrics.fMeasure(float(1))  # F1-score for label 1
test_f05_score = test_metrics.fMeasure(beta=0.5, label=float(1))  # F0.5-score for label 1

# AUC-ROC calculation requires BinaryClassificationMetrics
test_binary_metrics = BinaryClassificationMetrics(test_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))
test_auc_roc = test_binary_metrics.areaUnderROC

# Print train metrics
print("Train Metrics:")
print(f"Accuracy: {train_accuracy:.4f}")
print(f"Precision: {train_precision:.4f}")
print(f"Recall: {train_recall:.4f}")
print(f"F1 Score: {train_f1_score:.4f}")
print(f"F0.5 Score: {train_f05_score:.4f}")
print(f"AUC-ROC: {train_auc_roc:.4f}")

# Print test metrics
print("\nTest Metrics:")
print(f"Accuracy: {test_accuracy:.4f}")
print(f"Precision: {test_precision:.4f}")
print(f"Recall: {test_recall:.4f}")
print(f"F1 Score: {test_f1_score:.4f}")
print(f"F0.5 Score: {test_f05_score:.4f}")
print(f"AUC-ROC: {test_auc_roc:.4f}")

# COMMAND ----------

# Calculate and display the metrics on both training and test data

def evaluate_model(predictions, data_name):
    # Calculate the confusion matrix
    predictions_df = predictions.select('SUBTOPIC', 'prediction').toPandas()
    confusion_matrix = pd.crosstab(predictions_df['SUBTOPIC'], predictions_df['prediction'], rownames=['Actual'], colnames=['Predicted'])

    # Display the metrics and confusion matrix
    print(f"{data_name} Data Metrics:")
    print(f"  Confusion Matrix:\n{confusion_matrix}")

# Evaluate the model on training data
train_predictions = best_model.transform(train_data)
evaluate_model(train_predictions, "Training")

# Evaluate the model on test data
test_predictions = best_model.transform(test_data)
evaluate_model(test_predictions, "Test")

# COMMAND ----------

from pyspark.sql.types import DoubleType
from pyspark.sql.functions import udf, col

predictions = best_model.transform(transformed_df)
predictions = predictions.withColumn("Actual", test_data["SUBTOPIC"])

def extract_prob(v):
    try:
        return float(v[1])  # Your VectorUDT is of length 2
    except ValueError:
        return None

extract_prob_udf = udf(extract_prob, DoubleType())
predictions_with_prob = predictions.withColumn("prob_flag", extract_prob_udf(col("probability")))

# Define the threshold
threshold = 0.61

# Add the PredictionBetaScore column based on the threshold
predictions_with_prob = predictions_with_prob.withColumn(
    "PredictionBetaScore",
    when(col("prob_flag") > threshold, 1).otherwise(0)
)
# Display predictions
predictions_with_prob.select("CUSTOMERKEY","PROFILEDATE","BAN","Actual","prediction", "prob_flag","PredictionBetaScore").display()

# COMMAND ----------

# Custom F-beta Score Calculation
def f_beta_score(beta, precision, recall):
    beta_squared = beta ** 2
    return (1 + beta_squared) * (precision * recall) / (beta_squared * precision + recall)

def calculate_fbeta(df, beta):
    tp = df.filter((col("Actual") == 1) & (col("PredictionBetaScore") == 1)).count()
    fp = df.filter((col("Actual") == 0) & (col("PredictionBetaScore") == 1)).count()
    fn = df.filter((col("Actual") == 1) & (col("PredictionBetaScore") == 0)).count()
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    return f_beta_score(beta, precision, recall)

# Calculate F-beta score with beta=0.5
beta = 0.5
f_beta = calculate_fbeta(predictions_with_prob, beta)
print(f"F-beta (β={beta}) Score with threshold {threshold}: {f_beta}")

# COMMAND ----------

from mlflow.models.signature import infer_signature

# Compute signature
input_pandas = transformed_df.limit(10).toPandas()
output_pandas = predictions_with_prob.select(["Actual","prediction", "prob_flag", "PredictionBetaScore","probability"]).limit(1000).toPandas()
signature = mlflow.models.infer_signature(input_pandas, output_pandas)

# COMMAND ----------

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import fbeta_score, precision_recall_curve, classification_report
import pandas as pd

# Define a function to calculate F1 and F0.5 scores for given threshold
def calculate_scores(predictions, threshold):
    # Extract probability values
    prob_values = predictions['probability'].apply(lambda x: x[1])
    # Create a column with predicted label based on threshold
    predictions['predicted_label'] = np.where(prob_values >= threshold, 1.0, 0.0)
    # Calculate metrics
    f1_score = fbeta_score(predictions['SUBTOPIC'], predictions['predicted_label'], beta=1)
    f05_score = fbeta_score(predictions['SUBTOPIC'], predictions['predicted_label'], beta=0.5)
    return f1_score, f05_score

# Define a function to plot F1 and F0.5 scores against threshold
def plot_scores(thresholds, f1_scores, f05_scores):
    plt.plot(thresholds, f1_scores, label='F1 Score', marker='o')
    plt.plot(thresholds, f05_scores, label='F0.5 Score', marker='o')
    plt.xlabel('Threshold')
    plt.ylabel('Score')
    plt.title('F1 and F0.5 Scores vs. Threshold')
    plt.legend()
    plt.grid(True)
    plt.show()

# Get predictions for train and test data
train_predictions = best_model.transform(train_data).toPandas()
test_predictions = best_model.transform(test_data).toPandas()

# Define thresholds to test
thresholds = np.linspace(0, 1, 100)

# Calculate scores for train and test data
train_f1_scores = []
train_f05_scores = []
test_f1_scores = []
test_f05_scores = []

for threshold in thresholds:
    train_f1, train_f05 = calculate_scores(train_predictions, threshold)
    test_f1, test_f05 = calculate_scores(test_predictions, threshold)
    train_f1_scores.append(train_f1)
    train_f05_scores.append(train_f05)
    test_f1_scores.append(test_f1)
    test_f05_scores.append(test_f05)

# Plot the scores
plot_scores(thresholds, train_f1_scores, train_f05_scores)
plot_scores(thresholds, test_f1_scores, test_f05_scores)

# Find the optimal thresholds
optimal_threshold_f1 = thresholds[np.argmax(train_f1_scores)]
optimal_threshold_f05 = thresholds[np.argmax(train_f05_scores)]

# Calculate scores using optimal thresholds on the test data
test_f1_score_at_optimal_threshold_f1, test_f05_score_at_optimal_threshold_f1 = calculate_scores(test_predictions, optimal_threshold_f1)
test_f1_score_at_optimal_threshold_f05, test_f05_score_at_optimal_threshold_f05 = calculate_scores(test_predictions, optimal_threshold_f05)

print(f"Optimal threshold for F1 score: {optimal_threshold_f1}")
print(f"F1 Score at optimal threshold for F1 score: {test_f1_score_at_optimal_threshold_f1}")
print(f"Optimal threshold for F0.5 score: {optimal_threshold_f05}")
print(f"F0.5 Score at optimal threshold for F0.5 score: {test_f05_score_at_optimal_threshold_f05}")

# COMMAND ----------

# Print and log the metrics...
with mlflow.start_run(run_name="LateFee_Model_Evaluation"):
    run_id = mlflow.active_run().info.run_id
    
    # Log model parameters and metrics with MLflow
    mlflow.spark.log_model(best_model, "LateFeeModel")
    mlflow.log_metric("train_accuracy", round(train_accuracy, 4))
    mlflow.log_metric("train_precision", round(train_precision, 4))
    mlflow.log_metric("train_recall", round(train_recall, 4))
    mlflow.log_metric("train_f1_score", round(train_f1_score, 4))
    mlflow.log_metric("train_f05_score", round(train_f05_score, 4))
    mlflow.log_metric("train_auc_roc", round(train_auc_roc, 4))

    mlflow.log_metric("test_accuracy", round(test_accuracy, 4))
    mlflow.log_metric("test_precision", round(test_precision, 4))
    mlflow.log_metric("test_recall", round(test_recall, 4))
    mlflow.log_metric("test_f1_score", round(test_f1_score, 4))
    mlflow.log_metric("test_f05_score", round(test_f05_score, 4))
    mlflow.log_metric("test_auc_roc", round(test_auc_roc, 4))

    # Log additional metrics
    mlflow.log_metric("optimal_threshold_f1", round(optimal_threshold_f1, 4))
    mlflow.log_metric("test_f1_score_at_optimal_threshold_f1", round(test_f1_score_at_optimal_threshold_f1, 4))
    mlflow.log_metric("optimal_threshold_f05", round(optimal_threshold_f05, 4))
    mlflow.log_metric("test_f05_score_at_optimal_threshold_f05", round(test_f05_score_at_optimal_threshold_f05, 4))

    # Log hyperparameters
    mlflow.log_param("Num_Trees", best_model.getNumTrees)
    mlflow.log_param("Max_Depth", best_model.getMaxDepth())
    mlflow.log_param("Min_Instances_Per_Node", best_model.getMinInstancesPerNode())
    mlflow.log_param("Subsampling_Rate", best_model.getSubsamplingRate())

    # Log the model
    model_info = mlflow.spark.log_model(
        spark_model=best_model,
        artifact_path="LateFeeModel_artifacts",
        signature=signature,
        registered_model_name="devrzrcore.bdidb.latefee_intent_model" 
    )

# COMMAND ----------

import mlflow

client = mlflow.MlflowClient()
client.set_registered_model_alias("devrzrcore.bdidb.latefee_intent_model", "champion", 1)
client.get_model_version_by_alias("devrzrcore.bdidb.latefee_intent_model", "champion").version

# COMMAND ----------

champion_model = mlflow.spark.load_model("models:/devrzrcore.bdidb.latefee_intent_model/1")

# COMMAND ----------

# Calculate optimal F1 threshold and optimal Beta-0.5 threshold
optimal_threshold_f1_index = np.argmax(train_f1_scores)
optimal_threshold_f1 = thresholds[optimal_threshold_f1_index]

optimal_threshold_f05_index = np.argmax(train_f05_scores)
optimal_threshold_f05 = thresholds[optimal_threshold_f05_index]

# Find out the potential customers with scores over the optimal thresholds
train_predictions['prob_f1'] = train_predictions['probability'].apply(lambda x: x[1])
train_predictions['over_optimal_f1_threshold'] = train_predictions['prob_f1'] >= optimal_threshold_f1
train_predictions['over_optimal_f05_threshold'] = train_predictions['prob_f1'] >= optimal_threshold_f05

# Calculate the percentage of potential customers with a score over the optimal F1 threshold
percentage_over_optimal_f1_threshold = (train_predictions['over_optimal_f1_threshold'].sum() / len(train_predictions)) * 100

# Calculate the percentage of potential customers with a score over the optimal Beta-0.5 threshold
percentage_over_optimal_f05_threshold = (train_predictions['over_optimal_f05_threshold'].sum() / len(train_predictions)) * 100

# Calculate the percentage of potential customers with scores between the optimal Beta-0.5 threshold and the optimal F1 threshold
percentage_between_thresholds = 100 - percentage_over_optimal_f1_threshold - percentage_over_optimal_f05_threshold

# Print the results
print("1. Optimal F1 threshold:", optimal_threshold_f1)
print("2. Optimal Beta-0.5 threshold:", optimal_threshold_f05)
print("3. % of potential customers with a score over the optimal F1 threshold:", percentage_over_optimal_f1_threshold)
print("4. % of potential customers with a score over the optimal Beta-0.5 threshold:", percentage_over_optimal_f05_threshold)
print("5. % with scores between optimal Beta 0.5 and optimal F1:", percentage_between_thresholds)


# COMMAND ----------

# Plot F1 and Beta-0.5 scores against probability thresholds
plt.figure(figsize=(10, 6))
plt.plot(thresholds, train_f1_scores, label='F1 Score', marker='o')
plt.plot(thresholds, train_f05_scores, label='F0.5 Score', marker='o')

# Highlight optimal F1 threshold
plt.axvline(x=optimal_threshold_f1, color='r', linestyle='--', label='Optimal F1 Threshold')

# Highlight optimal Beta-0.5 threshold
plt.axvline(x=optimal_threshold_f05, color='b', linestyle='--', label='Optimal Beta-0.5 Threshold')

# Shade the regions
plt.fill_between(thresholds, 0, 1, where=(thresholds >= optimal_threshold_f1), color='green', alpha=0.3, label='High Propensity')
plt.fill_between(thresholds, 0, 1, where=((thresholds < optimal_threshold_f1) & (thresholds >= optimal_threshold_f05)), color='yellow', alpha=0.3, label='Medium Propensity')

plt.xlabel('Probability Threshold')
plt.ylabel('Score')
plt.title('F1 and F0.5 Scores vs. Probability Threshold')
plt.legend()
plt.grid(True)
plt.show()

