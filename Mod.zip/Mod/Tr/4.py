# Databricks notebook source
# DBTITLE 1,LIBRARIES IMPORT
import mlflow
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
import json
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql.functions import col, datediff, to_date, lit,  count, isnan, when
from pyspark.sql.types import DateType, NumericType, StringType
from pyspark.sql.types import FloatType
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, OneHotEncoder
from pyspark.ml.feature import StringIndexer
import numpy as np
import pandas as pd
from sklearn.metrics import fbeta_score, precision_recall_curve, classification_report
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.sql.functions import col, when, udf, rand, lit
from pyspark.sql.types import FloatType, DoubleType, IntegerType, LongType, StringType, DecimalType, TimestampType, BooleanType, StructType, StructField, DateType
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from imblearn.over_sampling import SMOTE
from pyspark.ml.classification import LogisticRegression
from pyspark.sql import functions as F
from pyspark.ml.feature import Imputer, StringIndexer, OneHotEncoder
from pyspark.ml.feature import VectorAssembler
from imblearn.over_sampling import SMOTE
from pyspark.sql import SparkSession
from pyspark.sql.functions import when
from pyspark.sql import Window
from pyspark.sql.functions import row_number
from pyspark.mllib.evaluation import MulticlassMetrics, BinaryClassificationMetrics
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import warnings
import mlflow
import mlflow.spark
from mlflow.models.signature import infer_signature
import json
import logging
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

# COMMAND ----------

# DBTITLE 1,Import Notebook Data_preprocessing_nb
# MAGIC %run ./Data_preprocessing_nb

# COMMAND ----------

# DBTITLE 1,READ INPUT PARAMETERS
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("preprocessing")  
logger.setLevel(logging.INFO)

# COMMAND ----------

"""{"training_data_table":"devrzrcore.bdidb.bdi_latefee_training_1",
    "threshold_scores_table":"devrzrcore.bdidb.dbr_customer_ml_callintent_threshold", "train_data_start_date":"2024-05-14", "train_data_limit":"100000", "tracking_uri": "/Volumes/devrzrcore/bdidb/bdi_raw_dbstage/bdi_customer_latefee/", "preprocessing_experiment_name":"preprocessing_latefee_intent", "training_experiment_name":"latefee_intent_model", "preprocessing_pipeline_name":"devrzrcore.bdidb.preprocessing_latefee_intent", "training_model_name":"devrzrcore.bdidb.latefee_intent_model"}"""

# COMMAND ----------

dbutils.widgets.text("pipeline_config_params","{}", "Pipeline configs")

PIPELINE_CONFIG_PARAMS = dbutils.widgets.get("pipeline_config_params")
config_params = json.loads(PIPELINE_CONFIG_PARAMS)

if config_params is None:
  logger.error(f"Config parameters not found")
  raise RuntimeError(f"Config parameters not found")

TRAIN_TABLE_NAME = config_params.get("training_data_table")
TRACKING_URI = config_params.get("tracking_uri")
EXPERIMENT_NAME = config_params.get("preprocessing_experiment_name")
REGISTER_PIPELINE_NAME = config_params.get("preprocessing_pipeline_name")

# COMMAND ----------

print('TRAIN_TABLE_NAME: ', TRAIN_TABLE_NAME)
print('REGISTER_PIPELINE_NAME: ', REGISTER_PIPELINE_NAME)
print('EXPERIMENT_NAME: ',EXPERIMENT_NAME)
print('config_params: ', config_params)

# COMMAND ----------

# DBTITLE 1,READ TRAINING DATA
select_query = f"""select * from {TRAIN_TABLE_NAME}"""

data = spark.sql(select_query)
num_rows = data.count()
num_cols = len(data.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# DBTITLE 1,Preprocess and Balanced the data
balanced_df = preprocess_data(data)

num_rows = balanced_df.count()
num_cols = len(balanced_df.columns)

print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

balanced_df.printSchema()

# COMMAND ----------

# DBTITLE 1,Encoding and Vector Assembler
def encoding_data(balanced_df):   
    # Convert Binary Categorical Features (late_fee_topic/No_late_fee_topic) to 0/1
    df_updated = balanced_df.withColumn("SUBTOPIC", F.when(col("SUBTOPIC") == "late_fee_topic", 1).otherwise(0))

    categorical_cols = [col_name for col_name in df_updated.columns 
                        if df_updated.schema[col_name].dataType == StringType() 
                        and col_name not in ["CUSTOMERKEY", "PROFILEDATE", "BAN","CUSTOMERCOHORTIND", 
                                             "LATESTLATEFEECHARGEDATE"]]
    
    timestamp_cols = [col_name for col_name in df_updated.columns 
                    if df_updated.schema[col_name].dataType == TimestampType()]
    
    numerical_cols = [col_name for col_name in df_updated.columns 
                    if df_updated.schema[col_name].dataType 
                    in [FloatType(), DoubleType(), IntegerType(), LongType(), DecimalType()]]

    decimal_cols = [col_name for col_name, col_type in df_updated.dtypes if 'decimal' in col_type]                 

    # Apply StringIndexer and OneHotEncoder to categorical columns
    indexers = [StringIndexer(inputCol=col_name, outputCol=col_name + "_indexed", handleInvalid='keep') 
                for col_name in categorical_cols]
    encoders = [OneHotEncoder(inputCol=col_name + "_indexed", outputCol=col_name + "_encoded") 
                for col_name in categorical_cols]

    # Combine indexers and encoders into a single list
    stages = indexers + encoders

    feature_columns = [col_name + "_encoded" for col_name in categorical_cols] + numerical_cols + timestamp_cols + \
                    decimal_cols

    # Exclude the target column
    feature_columns.remove("SUBTOPIC")
    #feature_columns.remove("BAN")

    assembler = VectorAssembler(inputCols= feature_columns , outputCol="features")                           

    # Combine all stages into a single pipeline
    pipeline = Pipeline(stages=stages + [assembler])

    pipeline_model = pipeline.fit(df_updated)
    
    return pipeline_model

# COMMAND ----------

pipeline_model = encoding_data(balanced_df)

# Transforming the DataFrame using the pipeline model
preprocessed_data = pipeline_model.transform(balanced_df)

preprocessed_data.display()

# COMMAND ----------

from mlflow.models.signature import infer_signature

# Compute signature
result = pipeline_model.transform(balanced_df.limit(10))
input_pandas = balanced_df.limit(10).toPandas()
output_pandas = result.toPandas()

signature = mlflow.models.infer_signature(input_pandas, output_pandas)

# COMMAND ----------

tracking_uri = f"{TRACKING_URI}{EXPERIMENT_NAME}" 
mlflow.set_tracking_uri(tracking_uri)

# Get the current tracking uri
tracking_uri = mlflow.get_tracking_uri()
logger.info(f"Current tracking uri: {tracking_uri}")

# COMMAND ----------

mlflow.set_registry_uri('databricks-uc')
mlflow.set_experiment(EXPERIMENT_NAME)

with mlflow.start_run():
    # Log the model
    model_info = mlflow.spark.log_model(
        spark_model=pipeline_model,
        artifact_path="artifacts",
        signature = signature,
        registered_model_name = REGISTER_PIPELINE_NAME,
    )

# COMMAND ----------

from mlflow import MlflowClient
# Read last version
client = MlflowClient()
preprocessing_pipeline_version = dict(client.search_model_versions(f"name = '{REGISTER_PIPELINE_NAME}'")[0])["version"]

# COMMAND ----------

output = { 
   "preprocessing_pipeline_version": preprocessing_pipeline_version,
  }
return_values = { 
   "output": json.dumps(output),
  }

dbutils.notebook.exit(json.dumps(return_values))