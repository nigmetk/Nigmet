# Databricks notebook source
from pyspark.ml.util import DefaultParamsWritable, DefaultParamsReadable
from pyspark.ml import Transformer
from pyspark.ml.param.shared import HasInputCols, HasOutputCols, Param, Params
from pyspark.sql.functions import col
from pyspark.sql.functions import col, datediff, to_date, lit,  count, isnan, when
from pyspark.sql.types import FloatType, IntegerType, DateType

# COMMAND ----------

class DateTransformer(Transformer, HasInputCols, HasOutputCols, DefaultParamsWritable, DefaultParamsReadable):
  """
  A custom transformer to convert a column to date type using the to_date function.
  """
  dateFormat = Param(Params._dummy(), "dateFormat", "Date format for to_date function.")

  def __init__(self, inputCols=None, outputCols=None, dateFormat="yyyy-MM-dd"):
    super(DateTransformer, self).__init__()
    self._setDefault(inputCols=None, outputCols=None, dateFormat="yyyy-MM-dd")
    self._set(inputCols=inputCols, outputCols=outputCols, dateFormat=dateFormat)

  def setDateFormat(self, value):
    return self._set(dateFormat=value)

  def getDateFormat(self):
    return self.getOrDefault(self.dateFormat)

  def _transform(self, df):
    # Applying the to_date function to the specified columns
    date_format = self.getDateFormat()
    for input_col, output_col in zip(self.getInputCols(), self.getOutputCols()):
        df = df.withColumn(output_col, to_date(col(input_col), date_format).cast(DateType()))
    return df


# COMMAND ----------

class DateDiffTransformer(Transformer, HasInputCols, HasOutputCols, DefaultParamsWritable, DefaultParamsReadable):
    """
    A custom transformer to compute the difference in days between two date columns.
    """
    referenceDateCol = Param(Params._dummy(), "referenceDateCol", "Name of the reference date column.")

    def __init__(self, inputCols=None, referenceDateCol=None, outputCols=None):
        super(DateDiffTransformer, self).__init__()
        self._setDefault(inputCols=None, referenceDateCol=None, outputCols=None)
        self._set(inputCols=inputCols, outputCols=outputCols, referenceDateCol=referenceDateCol)

    def setReferenceDateCol(self, value):
        return self._set(referenceDateCol=value)

    def getReferenceDateCol(self):
        return self.getOrDefault(self.referenceDateCol)

    def _transform(self, df):
        reference_date_col = self.getReferenceDateCol()
        for input_col, output_col in zip(self.getInputCols(), self.getOutputCols()):
            df = df.withColumn(output_col, datediff(col(input_col), col(reference_date_col)).cast(IntegerType()))
        return df

# COMMAND ----------

class FloatCastTransformer(Transformer, HasInputCols, HasOutputCols, DefaultParamsWritable, DefaultParamsReadable):
    """
    A custom transformer to cast a column to float type.
    """
    def __init__(self, inputCols=None, outputCols=None):
        super(FloatCastTransformer, self).__init__()
        self._setDefault(inputCols=None, outputCols=None)
        self._set(inputCols=inputCols, outputCols=outputCols)

    def _transform(self, df):
        for input_col, output_col in zip(self.getInputCols(), self.getOutputCols()):
            df = df.withColumn(output_col, col(input_col).cast(FloatType()))
        return df

# COMMAND ----------

class InputerTransformer(Transformer, HasInputCols, HasOutputCols, DefaultParamsWritable, DefaultParamsReadable):
    """
    A custom transformer to replace null values in a column with a specified default value.
    """
    value = Param(Params._dummy(), "value", "Value to inpute.")

    def __init__(self, inputCols=None, outputCols=None, value=None):
        super(InputerTransformer, self).__init__()
        self._setDefault(inputCols=None, outputCols=None, value=None)
        self._set(inputCols=inputCols, outputCols=outputCols, value=value)
    
    def setValue(self, value):
        return self._set(value=value)

    def getValue(self):
        return self.getOrDefault(self.value)

    def _transform(self, df):
        value = self.getValue()
        for input_col, output_col in zip(self.getInputCols(), self.getOutputCols()):
            df = df.withColumn(output_col, when(col(input_col).isNull(), value).otherwise(col(input_col)))
        return df