# Databricks notebook source
# DBTITLE 1,IMPORT LIBRARIES
import mlflow
from scipy import stats
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql.functions import col, datediff, to_date, lit,  count, isnan, when
from pyspark.sql.types import DateType, NumericType, StringType
from pyspark.sql.types import FloatType
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, OneHotEncoder
import json
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import numpy as np
import pandas as pd
from sklearn.metrics import fbeta_score, precision_recall_curve, classification_report
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.sql.functions import col, when, udf, rand, lit
from pyspark.sql.types import FloatType, DoubleType, IntegerType, LongType, StringType, DecimalType, TimestampType, BooleanType, StructType, StructField
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from imblearn.over_sampling import SMOTE
from pyspark.ml.classification import LogisticRegression
from pyspark.sql import functions as F
from pyspark.ml.feature import Imputer, StringIndexer, OneHotEncoder
from pyspark.ml.feature import VectorAssembler
from imblearn.over_sampling import SMOTE
from pyspark.sql import SparkSession
from pyspark.sql.functions import when
from pyspark.sql import Window
from pyspark.sql.functions import row_number
from pyspark.mllib.evaluation import MulticlassMetrics, BinaryClassificationMetrics
from sklearn.metrics import precision_recall_curve, fbeta_score,classification_report
import warnings
import mlflow
import mlflow.spark
from mlflow.models.signature import infer_signature
import json
import logging
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

# COMMAND ----------

# DBTITLE 1,Import Notebook Data_preprocessing_nb
# MAGIC %run ./Data_preprocessing_nb

# COMMAND ----------

# DBTITLE 1,INIT LOGGER
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("Training")
logger.setLevel(logging.INFO)

# COMMAND ----------

# DBTITLE 1,READ INPUT PARAMETERS
# Configs paramas to validate notebook separately
# input:
'''{"preprocessing_pipeline_version": "40"}'''
# pipeline_config_params:
"""{"training_data_table":"devrzrcore.bdidb.bdi_latefee_training_1",
    "threshold_scores_table":"devrzrcore.bdidb.dbr_customer_ml_callintent_threshold", "train_data_start_date":"2024-05-14", 
    "train_data_limit":"100000", 
    "tracking_uri": "/Volumes/devrzrcore/bdidb/bdi_raw_dbstage/bdi_customer_latefee/", "preprocessing_experiment_name":"preprocessing_latefee_intent", 
    "training_experiment_name":"latefee_intent_model", 
    "preprocessing_pipeline_name":"devrzrcore.bdidb.preprocessing_latefee_intent", 
    "training_model_name":"devrzrcore.bdidb.latefee_intent_model"}"""

# COMMAND ----------

dbutils.widgets.text("pipeline_config_params","{}", "Pipeline configs")
dbutils.widgets.text("input","{}", "Input params")

PIPELINE_CONFIG_PARAMS = dbutils.widgets.get("pipeline_config_params")
INPUT_PARAMS = dbutils.widgets.get("input")

# Check if the widget values are None
if PIPELINE_CONFIG_PARAMS is None or INPUT_PARAMS is None:
    raise RuntimeError("Widget values not found")
  
config_params = json.loads(PIPELINE_CONFIG_PARAMS)
input_params = json.loads(INPUT_PARAMS)

if config_params is None:
  logger.error(f"Config parameters not found")
  raise RuntimeError(f"Config parameters not found")

TRAIN_TABLE_NAME = config_params.get("training_data_table")
THRESHOLD_SCORES_TABLE = config_params.get("threshold_scores_table")
MODEL_NAME = config_params.get("training_model_name")
TRACKING_URI = config_params.get("tracking_uri")
MODEL_EXPERIMENT_PATH = config_params.get("training_experiment_name")
PREPROCESSING_PIPELINE_NAME = config_params.get("preprocessing_pipeline_name")
PREPROCESSING_PIPELINE_VERSION = input_params.get("preprocessing_pipeline_version")

# COMMAND ----------

print('TRAIN_TABLE_NAME: ', TRAIN_TABLE_NAME)
print('THRESHOLD_SCORES_TABLE: ',THRESHOLD_SCORES_TABLE)
print('MODEL_NAME: ', MODEL_NAME)
print('MODEL_EXPERIMENT_PATH: ', MODEL_EXPERIMENT_PATH)
print('PREPROCESSING_PIPELINE_NAME: ', PREPROCESSING_PIPELINE_NAME)
print('PREPROCESSING_PIPELINE_VERSION: ', PREPROCESSING_PIPELINE_VERSION)

# COMMAND ----------

logger.info(f"TRAIN_TABLE_NAME: {TRAIN_TABLE_NAME}")
logger.info(f"THRESHOLD_SCORES_TABLE: {THRESHOLD_SCORES_TABLE}")
logger.info(f"MODEL_NAME: {MODEL_NAME}")
logger.info(f"MODEL_EXPERIMENT_PATH: {MODEL_EXPERIMENT_PATH}")
logger.info(f"PREPROCESSING_PIPELINE_NAME: {PREPROCESSING_PIPELINE_NAME}")
logger.info(f"PREPROCESSING_PIPELINE_VERSION: {PREPROCESSING_PIPELINE_VERSION}")

# COMMAND ----------

# DBTITLE 1,LOAD DATA
select_query = f"""select * from {TRAIN_TABLE_NAME}"""

data = spark.sql(select_query)
num_rows = data.count()
num_cols = len(data.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# DBTITLE 1,Load pipeline preprocessing
mlflow.set_registry_uri('databricks-uc')
preprocessing_pipeline = mlflow.spark.load_model(f"models:/{PREPROCESSING_PIPELINE_NAME}/{PREPROCESSING_PIPELINE_VERSION}")

# COMMAND ----------

# Import the functions from the file
balanced_df = preprocess_data(data)

num_rows = balanced_df.count()
num_cols = len(balanced_df.columns)
print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_cols}")

# COMMAND ----------

# DBTITLE 1,Transform data with pipeline
# Convert Binary Categorical Features (late_fee_topic/No_late_fee_topic) to 0/1
df_updated = balanced_df.withColumn("SUBTOPIC", F.when(col("SUBTOPIC") == "late_fee_topic", 1).otherwise(0))
transformed_df = preprocessing_pipeline.transform(df_updated)
transformed_df.display()

# COMMAND ----------

# DBTITLE 1,Test and Train data split
# Split the data into training and test sets
(train_data, test_data) = transformed_df.randomSplit([0.8, 0.2], seed=42)

# Validate changes
num_rows = train_data.count()
num_cols = len(train_data.columns)
num_rows2 = test_data.count()
num_cols2 = len(test_data.columns)

print(f"Number of rows in train_data: {num_rows}")
print(f"Number of columns in train_data: {num_cols}")
print(f"Number of rows in test_data: {num_rows2}")
print(f"Number of columns in test_data: {num_cols2}")

# COMMAND ----------

stages=[]
estimator= RandomForestClassifier(featuresCol='features', labelCol= "SUBTOPIC" , maxDepth= 12,  numTrees=150,minInstancesPerNode = 10, seed=42)
stages.append(estimator)
model_pipeline=Pipeline(stages=stages)

# COMMAND ----------

mlflow.spark.autolog(disable=True)
mlflow.autolog(disable=True)
best_model =model_pipeline.fit(train_data)

# COMMAND ----------

# DBTITLE 1,Prediction analysis according to LateFee Class [Label1]
# Evaluate the model on train data
train_predictions = best_model.transform(train_data)
train_metrics = MulticlassMetrics(train_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))

# Calculate metrics for each label
train_accuracy = train_metrics.accuracy
train_precision = train_metrics.precision(label=1)  # Precision for label 1
train_recall = train_metrics.recall(label=1)  # Recall for label 1
train_f1_score = train_metrics.fMeasure(float(1))  # F1-score for label 1
train_f05_score = train_metrics.fMeasure(beta=0.5, label=float(1))  # F0.5-score for label 1

# AUC-ROC calculation requires BinaryClassificationMetrics
train_binary_metrics = BinaryClassificationMetrics(train_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))
train_auc_roc = train_binary_metrics.areaUnderROC

# Repeat the same for test data
# Evaluate the model on test data
test_predictions = best_model.transform(test_data)
test_metrics = MulticlassMetrics(test_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))

# Calculate metrics for each label
test_accuracy = test_metrics.accuracy
test_precision = test_metrics.precision(label=1)  # Precision for label 1
test_recall = test_metrics.recall(label=1)  # Recall for label 1
test_f1_score = test_metrics.fMeasure(float(1))  # F1-score for label 1
test_f05_score = test_metrics.fMeasure(beta=0.5, label=float(1))  # F0.5-score for label 1

# AUC-ROC calculation requires BinaryClassificationMetrics
test_binary_metrics = BinaryClassificationMetrics(test_predictions.select("prediction", "SUBTOPIC").rdd.map(lambda x: (float(x.prediction), float(x.SUBTOPIC))))
test_auc_roc = test_binary_metrics.areaUnderROC

# Print and log the metrics
# Print train metrics
print("Train Metrics:")
print(f"Accuracy: {train_accuracy:.4f}")
print(f"Precision: {train_precision:.4f}")
print(f"Recall: {train_recall:.4f}")
print(f"F1 Score: {train_f1_score:.4f}")
print(f"F0.5 Score: {train_f05_score:.4f}")
print(f"AUC-ROC: {train_auc_roc:.4f}")

# Print test metrics
print("\nTest Metrics:")
print(f"Accuracy: {test_accuracy:.4f}")
print(f"Precision: {test_precision:.4f}")
print(f"Recall: {test_recall:.4f}")
print(f"F1 Score: {test_f1_score:.4f}")
print(f"F0.5 Score: {test_f05_score:.4f}")
print(f"AUC-ROC: {test_auc_roc:.4f}")

# COMMAND ----------

results= best_model.transform(test_data)

# COMMAND ----------

# DBTITLE 1,Signature
#change signature
from mlflow.models.signature import infer_signature

# Compute signature
result = best_model.transform(train_data.select("features").limit(10))
input_pandas = train_data.select("features").limit(10).toPandas()
output_pandas = results.select("probability").toPandas()
signature = mlflow.models.infer_signature(input_pandas, output_pandas)

# COMMAND ----------

# DBTITLE 1,MLflow Set tracking URI
tracking_uri = f"{TRACKING_URI}{MODEL_EXPERIMENT_PATH}"
mlflow.set_tracking_uri(tracking_uri)

# Get the current tracking uri
tracking_uri = mlflow.get_tracking_uri()
logger.info(f"Current tracking uri: {tracking_uri}")

# COMMAND ----------

# DBTITLE 1,Registration
mlflow.set_registry_uri('databricks-uc') 
mlflow.set_experiment(MODEL_EXPERIMENT_PATH)

# Print and log the metrics...
with mlflow.start_run():
    
    # Log model parameters and metrics with MLflow
    mlflow.spark.log_model(best_model, "late_fee")
    mlflow.log_metric("train_accuracy", round(train_accuracy, 4))
    mlflow.log_metric("train_precision", round(train_precision, 4))
    mlflow.log_metric("train_recall", round(train_recall, 4))
    mlflow.log_metric("train_f1_score", round(train_f1_score, 4))
    mlflow.log_metric("train_f05_score", round(train_f05_score, 4))
    mlflow.log_metric("train_auc_roc", round(train_auc_roc, 4))

    mlflow.log_metric("test_accuracy", round(test_accuracy, 4))
    mlflow.log_metric("test_precision", round(test_precision, 4))
    mlflow.log_metric("test_recall", round(test_recall, 4))
    mlflow.log_metric("test_f1_score", round(test_f1_score, 4))
    mlflow.log_metric("test_f05_score", round(test_f05_score, 4))
    mlflow.log_metric("test_auc_roc", round(test_auc_roc, 4))

    # Log additional metrics
    mlflow.log_metric("MED_INTENT_THRESHOLD", 0.60 )
    mlflow.log_metric("HIGH_INTENT_THRESHOLD", 0.67 )

    # Log hyperparameters
    mlflow.log_param("Num_Trees" , 150)
    mlflow.log_param("Max_Depth", 12)
    mlflow.log_param("Min_Instances_Per_Node", 10)
    mlflow.log_param("Subsampling_Rate", 1.0)

    # Log the model
    model_info = mlflow.spark.log_model(
        spark_model=best_model,
        artifact_path="artifacts",
        signature=signature,
        registered_model_name= MODEL_NAME 
    )

# COMMAND ----------

from mlflow import MlflowClient
# Read last version
client = MlflowClient()
model_version = dict(client.search_model_versions(f"name = '{MODEL_NAME}'")[0])["version"]

# COMMAND ----------

logger.info(f"The latest version of model {model_version}")

# COMMAND ----------

# DBTITLE 1,Set alias and tags
client.set_model_version_tag(name=MODEL_NAME, version=model_version, key='stage', value='prod')
client.set_registered_model_alias(MODEL_NAME, "Champion", model_version)

client.set_model_version_tag(name=PREPROCESSING_PIPELINE_NAME, version=PREPROCESSING_PIPELINE_VERSION, key='stage', value='prod')
client.set_registered_model_alias(PREPROCESSING_PIPELINE_NAME, "Champion", PREPROCESSING_PIPELINE_VERSION)

# COMMAND ----------

# DBTITLE 1,Save training threshold values
# Round the threshold values to 2 decimal places
optimal_threshold_f05_rounded = 0.67
optimal_threshold_f1_rounded = 0.60

# Create or insert
spark.sql(f"""CREATE TABLE IF NOT EXISTS {THRESHOLD_SCORES_TABLE} (
  INFERENCE_DATE TIMESTAMP, 
  INTENT_NAME STRING,
  HIGH_INTENT_THRESHOLD FLOAT, 
  MED_INTENT_THRESHOLD FLOAT
)
USING DELTA;"""
)

spark.sql(f"""INSERT INTO {THRESHOLD_SCORES_TABLE} (INFERENCE_DATE, INTENT_NAME, HIGH_INTENT_THRESHOLD, MED_INTENT_THRESHOLD) VALUES
  (current_timestamp(), 'late_fee', {optimal_threshold_f05_rounded}, {optimal_threshold_f1_rounded})"""
)

# COMMAND ----------

# Display the contents of threshold table
df = spark.sql(f"SELECT * FROM {THRESHOLD_SCORES_TABLE};")

df.show()

# COMMAND ----------

logger.info(f"Threshold High: {optimal_threshold_f05_rounded:.2f}")
logger.info(f"Threshold Midium: {optimal_threshold_f1_rounded:.2f}")

logger.info(f"*** BDI customer latefee intent training completed ***")